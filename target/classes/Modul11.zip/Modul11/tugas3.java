/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modul11;

/**
 *
 * @author Crusts
 */
import java.util.Scanner;

public class tugas3 {

    static void bacaTitik() {
        double x1, x2, x3, y1, y2, y3;
        double sisiA, sisiB, sisiC;
        Scanner key = new Scanner(System.in);

        System.out.println("Absis Titik 1 (x1) :");
        x1 = key.nextDouble();
        System.out.println("Ordinat Titik 1 (y1) :");
        y1 = key.nextDouble();
        System.out.println("Absis Titik 2 (x2) :");
        x2 = key.nextDouble();
        System.out.println("Ordinat Titik 2 (y2) :");
        y2 = key.nextDouble();
        System.out.println("Absis Titik (x3) 3 :");
        x3 = key.nextDouble();
        System.out.println("Ordinat Titik 3 (y3) :");
        y3 = key.nextDouble();

        sisiA = hitungJarak(x1, y1, x2, y2);
        sisiB = hitungJarak(x2, y2, x3, y3);
        sisiC = hitungJarak(x3, y3, x1, y1);
        System.out.println(sisiA);
        System.out.println(sisiB);
        System.out.println(sisiC);
        System.out.println("Keliling Segitiga : " + hitungKeliling(sisiA, sisiB, sisiC));
        if (hitungKeliling(sisiA, sisiB, sisiC)!=0) {
            System.out.println("Luas Segitiga : " + hitungLuas(sisiA, sisiB, sisiC));
        } else {
            System.out.println("Luas Segitiga Tidak Bisa Dicari Karena Segitiga Sembarang");
        }
        

    }

    static double hitungJarak(double x1, double y1, double x2, double y2) {
        return Math.sqrt(((x1 - x2) * (x1 - x2)) + ((y1 - y2) * (y1 - y2)));
    }

    static double hitungKeliling(double sisiA, double sisiB, double sisiC) {
        return sisiA + sisiB + sisiC;
    }

    static double hitungLuas(double sisiA, double sisiB, double sisiC) {
        //Sama Sisi
        if (sisiA == sisiB && sisiA == sisiC) {
            return Math.sqrt((sisiA * sisiA)-((sisiA/2)*(sisiA/2))) * (sisiA / 2);
        } //Sama Kaki
        else if (sisiA == sisiB) {
            return Math.sqrt((sisiB * sisiB)-((sisiC/2)*(sisiC/2))) * (sisiC / 2);
        } else if (sisiB == sisiC) {
            return Math.sqrt((sisiC * sisiC)-((sisiA/2)*(sisiA/2))) * (sisiA / 2);
        } else if (sisiA == sisiC) {
            return Math.sqrt((sisiC * sisiC)-((sisiB/2)*(sisiB/2))) * (sisiB / 2);
        } //Segitiga Siku
        else if ((sisiA * sisiA) == ((sisiB * sisiB) + (sisiC * sisiC))) {
            return sisiB * sisiC / 2;
        } else if ((sisiB * sisiB) == ((sisiA * sisiA) + (sisiC * sisiC))) {
            return sisiA * sisiC / 2;
        } else if ((sisiC * sisiC) == ((sisiB * sisiB) + (sisiA * sisiA))) {
            return sisiB * sisiA / 2;
        } else {
            return 0;
        }

    }

    public static void main(String[] args) {
        bacaTitik();
    }
}
