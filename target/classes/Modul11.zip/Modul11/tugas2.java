/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modul11;

import java.util.Scanner;

/**
 *
 * @author Crusts
 */
public class tugas2 {
    public static void main(String[] args) {
        int baris,hasil;
        Scanner key = new Scanner(System.in);
        System.out.println("Masukkan Nilai :");
        baris=key.nextInt();
        
        for (int i = 0; i <= baris; i++) {
            
            hasil=(faktorial(baris)/(faktorial(baris-i)*faktorial(i)));
            System.out.print(hasil+" ");
        }
    }

    static int faktorial(int n) {
        int hasil=1;
        
        for (int i = 1; i <= n; i++) {
            hasil=hasil*i;
            
        }
        return hasil;
    }
}
