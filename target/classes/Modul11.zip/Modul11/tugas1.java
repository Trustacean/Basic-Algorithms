/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modul11;

/**
 *
 * @author Crusts
 */
import java.util.Scanner;

public class tugas1 {

    public static void main(String[] args) {
        int n, r;
        int c;
        Scanner key = new Scanner(System.in);
        System.out.println("Program Hitung Kombinasi");
        System.out.println("Total Objek :");
        n = key.nextInt();
        System.out.println("Yang Ingin Di Pilih :");
        r = key.nextInt();
        
        c=faktorial(n)/(faktorial(n-r)*faktorial(r));
        
        System.out.println("Hasil Kombinasi :"+c);
    }

    static int faktorial(int n) {
        int hasil=1;
        for (int i = 1; i <= n; i++) {
            hasil=hasil*i;
        }
        return hasil;
    }
}
